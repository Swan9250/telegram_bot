import json

file = input('Укажи абсолютный путь до файла: ')

with open(file, 'r') as f:
    text = f.read()
    text = text.replace("'",'"')
    text = text.replace("False", "0")
    text = text.replace("True", "1")
    text = json.loads(text)
    text = json.dumps(text, indent=4, sort_keys=True)
    print(text)

