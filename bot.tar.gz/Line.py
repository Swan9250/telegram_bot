#!/usr/bin/env python

from request import send_request

class Line():
    IDS = {'first': 2,
           'second': 13,
           'third': 14,
           'free': 12,
           'move': 15,
           'automove': 11,
           'admin': 4,
           'manager': 6,
           'buh': 8,
           'vps': 17,
           'test': 19}

    def __init__(self, line: str, page=0, page_size=1000):
        self.line = line
        self.page = page
        self.page_size = page_size

    def __call__(self, line: str, page=0, page_size=1000):
        self.line = line
        self.page = page
        self.page_size = page_size
        return self.list

    def get(self) -> list:
        url = 'https://api-internal.beget.com/helpdesk/ticket/all'
        json = {'page': self.page,
                'page_size': self.page_size}
        if type(self.line) == str:
            line_id = Line.IDS[self.line]
            json['scope'] = [{'by_queue_id': {'queue_id': [line_id]}}]
        elif isinstance(self.line, ('int', 'list')):
            if type(self.line) == int:
                employee_id = [self.line]
            else:
                employee_id = self.line
            json['scope'] = [{'by_employee_id': {'employee_id': [employee_id]}}]
        else:
            raise Exception("Input integer (employee id) or string ('first'/'automove'/...) value.")

        response = send_request('post', url, json=json).json()
        tickets = response.get('ticket')
        return tickets

    def get_last_comments(self, tickets_id=[], only_last=True):
        url = 'https://api-internal.beget.com/helpdesk/comment/all'
        if not tickets_id:
            if self.line:
                tickets_id = [ticket['id'] for ticket in self.line]
            else:
                raise TypeError("Don't get a tickets_id list")
        json = {"scope": [{"by_ticket_id": {"ticket_id": tickets_id,
                                            "only_last": only_last}}],
                "page": 0,
                "page_size": 10000}
        response = send_request('post', url, json=json).json()
        return response

    def get_automove_statuses(self, tickets_id=[]):
        url = 'https://helpdesk.beget.ru/api-frontend/site-transfer/get-tasks-statuses-by-tickets-ids'
        if not tickets_id and self.line:
            tickets_id = [ticket['id'] for ticket in self.line]
        data = {'ticketsIds': tickets_id}
        raw_response = send_request('post', url, json=data).json()
        statuses = raw_response.get('answer').get('result')
        return statuses

    def __getattr__(self, attr):
        if attr == 'list':
            return self.get()

    # def search(self, **kwargs):  # employee_id, min_date, max_date, page=0):
    #     url = 'https://api-internal.beget.com/helpdesk/ticket/all'
    #     if page := kwargs.get('page'):
    #         json['page'] = page

    #     json = {
    #         'scope': [
    #             {'by_employee_id': {'employee_id': [employee_id]}},
    #             {'post_created_at_min': {'post_created_at_min': min_date}},
    #             {'post_created_at_max': {'post_created_at_max': max_date}},
    #             {'only_status_in': {'status_id': [3, 2, 4, 5, 1]}},
    #             {'by_action': {'action': ['ANSWER']}}],
    #         'page': page,
    #         'page_size': 250}
    #     response = send_request('post',
    #                             url,
    #                             json=json
    #                             ).json()

    #     search_line = []
    #     page_count = response.get('page_count')
    #     if not page and page_count > 1:
    #         for page in range(1, page_count):
    #             search_line += get_search_line(employee_id, min_date, max_date, page)

    #     search_line += response.get('ticket')

    #     return search_line
