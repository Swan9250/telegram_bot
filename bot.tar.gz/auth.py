import json
import getpass
import requests

FILE_TOKEN = '/tmp/.gsp_token'

class Auth:
    @staticmethod
    def write(login, token):
        auth_data = {'login': login,
                     'token': token}

        with open(FILE_TOKEN, 'w') as file:
            json.dump(auth_data, file)

    def new(self):
#        login = input('LDAP login: ')
#        password = getpass.getpass()
        login = 'vstanotin'
        password = 'Vstanotin2323120686'
        url = 'https://enter.beget.ru/login'
        data = {'login': login,
                'password': password}

        request = requests.post(url,
                                data=data
                                ).json()

        error = request.get('error')
        if error:
            raise Exception(error)
        else:
            self.token = request.get('token')
            self.login = login

        Auth.write(self.login, self.token)

    def __init__(self):
        try:
            with open(FILE_TOKEN, 'r') as file:
                auth_data = json.load(file)
                if not auth_data:
                    raise IOError
                login = auth_data.get('login')
                token = auth_data.get('token')
                if not login or not token:
                    raise IOError
            self.login, self.token = login, token
        except IOError:
            self.new()
            self.write(self.login, self.token)
