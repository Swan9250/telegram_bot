# telegram_bot
Count score of kicker games

To run this bot you need:
  * Python3.9
  * python-telegram-bot module

To start run this:
`python3.9 bot.py`
