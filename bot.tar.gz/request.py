import requests
import logging
from auth import Auth


def send_request(method: str, url: str, **headers):
    method = method.lower()

    for _ in range(2):
        if method == 'get':
            if 'api-internal.beget.com' in url or \
            'helpdesk.beget.ru' in url:
                headers.setdefault('headers', {})
                headers['headers']['authorization'] = f"Bearer {Auth().token}"
            else:
                headers['cookies'] = {'begetInnerJWT': Auth().token}
        elif method in ('post', 'put'):
            headers.setdefault('headers', {})
            if 'hp.beget.ru' in url:
                headers['headers']['cookie'] = f"begetInnerJWT={Auth().token}"
            elif 'enter.beget.ru' in url:
                pass
            else:
                headers['headers']['authorization'] = f"Bearer {Auth().token}"

        response = requests.request(method, url, **headers)
        status_code = response.status_code
        if status_code == 401:
            Auth().new()
        else:
            break
    if status_code != 200:
        message = f"{status_code} {method} {url} {headers}"
        logging.warning(message)

    return response
